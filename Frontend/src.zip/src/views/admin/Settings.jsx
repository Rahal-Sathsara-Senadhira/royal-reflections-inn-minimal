import React from "react";

export default function Settings() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Settings</h1>
      <div className="bg-white border border-gray-200 rounded-xl p-4">
        <p className="text-gray-600">Settings content goes here…</p>
      </div>
    </div>
  );
}
